﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsForms2
{
    public partial class Form1 : Form
    {
        private MySqlConnection databaseConection()
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connectionString);
            return conn;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Hide();
            panel2.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SIGN_IN_Click(object sender, EventArgs e)
        {
            panel2.Show();
        }

        private void CREATEAC_Click(object sender, EventArgs e)
        {
            panel1.Show();
        }

        private void SIGNADMIN_Click(object sender, EventArgs e)
        {
            Form2 F2 = new Form2();
            this.Hide();
            F2.Show();
        }

        private void label2_Click(object sender, EventArgs e)/// ปุ่ม Sign In
        {
            MySqlConnection conn = databaseConection();
            conn.Open();

            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT *FROM information WHERE Username = \"{User.Text}\" AND Password = \"{Pass.Text}\"";


            MySqlDataReader row = cmd.ExecuteReader();
            if (row.HasRows)
            {
                Form3 F3 = new Form3();
                MySqlConnection conn1 = databaseConection();
                conn1.Open();
                MySqlCommand cmds = new MySqlCommand("SELECT username from information where Username=@Username", conn1);
                cmds.Parameters.AddWithValue("@Username", (User.Text));
                MySqlDataReader da = cmds.ExecuteReader();
                while (da.Read())
                {
                    F3.user = da.GetValue(0).ToString();
                }
                this.Hide();
                F3.Show();

            }
            else
            {
                MessageBox.Show("Username Or Password Is Not Correct");
                User.Clear();
                Pass.Clear();
                User.Focus();
            }
            conn.Close();
            
        }

        private void showpass_CheckedChanged(object sender, EventArgs e)
        {
            if (showpass.Checked)
            {
                string a = Pass.Text;
                Pass.PasswordChar = '\0';
            }
            else
            {
                Pass.PasswordChar = '*';
            }
        }

        private void label8_Click(object sender, EventArgs e)///ปุ่มสมัครใช้งาน
        {
  
            if (name.Text == "" || username.Text == "" || password.Text == "" || tel.Text == "" || ConfirmPassword.Text == "")
            {
                MessageBox.Show("Please Fill Your Information", "", MessageBoxButtons.OK);
            }
            else if (tel.TextLength < 10) //เบอร์โทร 10 ตัว
            {
                MessageBox.Show("Please Input Your Correct Number", "", MessageBoxButtons.OK);
            }
            else if (password.Text != ConfirmPassword.Text)
            {
                MessageBox.Show("Password Is Not Match", "", MessageBoxButtons.OK);
            }
            else
            {
                string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
                MySqlConnection conn = new MySqlConnection(connectionString);
                conn.Open();
                String sql = "INSERT INTO information(username,password,name,tel,email,address)VALUES('" + username.Text + "','" + password.Text + "','" + name.Text + "','" + tel.Text + "','" + email.Text + "','" + address.Text + "')";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                int rows = cmd.ExecuteNonQuery();
                MessageBox.Show("WELCOME TO DUFTKERZEN ");
                panel1.Hide();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                string a = password.Text;
                string b = ConfirmPassword.Text;
                password.PasswordChar = '\0';
                ConfirmPassword.PasswordChar = '\0';
            }
            else
            {
                password.PasswordChar = '*';
                ConfirmPassword.PasswordChar = '*';
            }
        }

        private void User_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void User_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (System.Text.Encoding.UTF8.GetByteCount(new char[] { e.KeyChar }) > 1)
            {
                e.Handled = true;
            }
        }

        private void Pass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(System.Text.Encoding.UTF8.GetByteCount(new char[] { e.KeyChar }) > 1)
            {
                e.Handled = true;
            }
        }

        private void username_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (System.Text.Encoding.UTF8.GetByteCount(new char[] { e.KeyChar }) > 1)
            {
                e.Handled = true;
            }
        }

        private void password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (System.Text.Encoding.UTF8.GetByteCount(new char[] { e.KeyChar }) > 1)
            {
                e.Handled = true;
            }
        }

        private void ConfirmPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (System.Text.Encoding.UTF8.GetByteCount(new char[] { e.KeyChar }) > 1)
            {
                e.Handled = true;
            }
        }

        private void name_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tel_TextChanged(object sender, EventArgs e)
        {

        }

        private void email_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (System.Text.Encoding.UTF8.GetByteCount(new char[] { e.KeyChar }) > 1)
            {
                e.Handled = true;
            }
        }
    }
}
