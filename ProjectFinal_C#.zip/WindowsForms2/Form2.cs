﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;

namespace WindowsForms2
{
    public partial class Form2 : Form
    {
        List<Bill> allbill = new List<Bill>();
        private MySqlConnection databaseConection()
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connectionString);
            return conn;
        }

        private void showEquipment()///stock add update delete สินค้า
        {
            MySqlConnection conn = databaseConection();
            DataSet ds = new DataSet();
            conn.Open();
            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT *FROM equipment";
            checkstock = "SELECT *FROM equipment";

            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);

            conn.Close();

            dataEquipment.DataSource = ds.Tables[0].DefaultView;
        }

        private void showStock()///ประวัติการซื้อ-ขายสินค้า
        {
            MySqlConnection conn = databaseConection();
            DataSet ds = new DataSet();
            conn.Open();
            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT *FROM history";

            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);

            conn.Close();

            dataStock.DataSource = ds.Tables[0].DefaultView;
        }

        public Form2()
        {
            InitializeComponent();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            panel2.Show();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            panel2.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            showEquipment();
            showStock();
            panel1.Hide();
            panel2.Hide();
        }

        public int sum;
        public int num;

        private void label21_Click(object sender, EventArgs e)///ปุ่ม Log in แอดมิน
        {
            MySqlConnection conn = databaseConection();
            conn.Open();

            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT *FROM admin WHERE username = \"{adminuser.Text}\" AND password = \"{adminpassword.Text}\"";
            MySqlDataReader row = cmd.ExecuteReader();
            if (row.HasRows)
            {
                panel1.Show();
            }
            else
            {
                MessageBox.Show("Username Or Password Is Not Correct");
            }
            conn.Close();

        }

        private void showpass_CheckedChanged(object sender, EventArgs e)
        {
            if (showpass.Checked)
            {
                string a = adminpassword.Text;
                adminpassword.PasswordChar = '\0';
            }
            else
            {
                adminpassword.PasswordChar = '*';
            }
        }

        private void Addpic_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp; *png;)|*.jpg; *.jpeg; *.gif; *.bmp *.png;";
            if (open.ShowDialog() == DialogResult.OK)
            {
                pictureBox3.Image = new Bitmap(open.FileName);
                textBox1.Text = open.FileName;
            }
        }

        private void add_Click(object sender, EventArgs e)///แอดข้อมูลลงสต๊อก
        {
            string connection = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connection);
            byte[] image = null;
            //pictureBox3.ImageLocation = textLocation.Text;
            string filepath = textBox1.Text;
            FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            image = br.ReadBytes((int)fs.Length);
            string sql = $" INSERT INTO equipment (Scented,Size,Amount,Price,Image) VALUES(\"{ Scented.Text }\",\"{ Size.Text}\",\"{ Amount.Text}\",\"{ Price.Text}\",@Imgg)";
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.Add(new MySqlParameter("@Imgg", image));
                int x = cmd.ExecuteNonQuery();
                conn.Close();
                showEquipment();
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            int selectedRowmm = dataEquipment.CurrentCell.RowIndex;
            string editId = Convert.ToString(dataEquipment.Rows[selectedRowmm].Cells["Scented"].Value);
            string connection = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connection);
            String sql = "UPDATE equipment SET Scented = '" + Scented.Text + "',Size ='" + Size.Text + "',Amount = '" + Amount.Text + "',Price = '" + Price.Text + "' WHERE Scented = '" + editId + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            conn.Close();
            if (rows > 0)
            {
                MessageBox.Show("Update Stock", "DUFTKERZEN", MessageBoxButtons.OK);
                showEquipment();
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            int selectedRowmm = dataEquipment.CurrentCell.RowIndex;
            string editId = Convert.ToString(dataEquipment.Rows[selectedRowmm].Cells["Scented"].Value);
            string connection = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connection);
            String sql = "DELETE FROM equipment WHERE Scented = '" + editId + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            int rows = cmd.ExecuteNonQuery();
            conn.Close();
            if (rows > 0)
            {
                MessageBox.Show("Delete Stock", "DUFTKERZEN", MessageBoxButtons.OK);
                showEquipment();
            }
        }

        private void dataEquipment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dataEquipment.CurrentRow.Selected = true;
            Scented.Text = dataEquipment.Rows[e.RowIndex].Cells["Scented"].FormattedValue.ToString();
            Size.Text = dataEquipment.Rows[e.RowIndex].Cells["Size"].FormattedValue.ToString();
            Amount.Text = dataEquipment.Rows[e.RowIndex].Cells["Amount"].FormattedValue.ToString();
            Price.Text = dataEquipment.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connectionString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand($"SELECT Image FROM equipment WHERE Scented =\"{ Scented.Text }\"", conn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["Image"]);
                pictureBox3.Image = new Bitmap(ms);
            }
        }

        private void adminuser_TextChanged(object sender, EventArgs e)
        {

        }

        private void adminpassword_TextChanged(object sender, EventArgs e)
        {

        }

        public string printreport;
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("DUFTKERZEN", new Font("supermarket", 30, FontStyle.Bold), Brushes.MediumSeaGreen, new Point(75, 100));
            e.Graphics.DrawString("sales history", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 150));
            if (dateTimePicker1.Text == dateTimePicker2.Text)
            {
                e.Graphics.DrawString("Date : " + dateTimePicker1.Text, new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 260));
            }
            else
            {
                e.Graphics.DrawString("First Day : " + dateTimePicker1.Text , new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 230));
                e.Graphics.DrawString("Last Day : " + dateTimePicker2.Text , new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 260));
            }

            if (searchbox.Text == "")
            {
                e.Graphics.DrawString("Scented : " + "Sales History", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 200));
            }
            else
            {
                e.Graphics.DrawString("Scented : " + searchbox.Text, new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 200));
            }

            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 285));
            e.Graphics.DrawString("Scented                           Size                       Amount                    Price", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 315));
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 345));
            int number = 1;
            int y = 345;

            foreach (var i in allbill)
            {
                y = y + 35;
                e.Graphics.DrawString("   " + i.name_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(70, y));
                e.Graphics.DrawString("   " + i.size_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(280, y));
                e.Graphics.DrawString("   " + i.amount_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(520, y));
                e.Graphics.DrawString("   " + i.price_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(700, y));
                number = number + 1;
            }
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, y + 30));
            e.Graphics.DrawString("Sales Amount :  " + amounthistory.Text +  " Container", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(500, ((y + 30) + 45) + 45));
            e.Graphics.DrawString("Total Price :  " + pricehistory.Text +   " Baht", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(500, (((y + 30) + 45) + 45) + 45));
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {
            allbill.Clear();
            MySqlConnection conn = databaseConection();
            DataSet ds = new DataSet();
            conn.Open();
            MySqlCommand cmd;
            cmd = conn.CreateCommand();

            if (dateTimePicker1.Text == dateTimePicker2.Text)
            {

                if (searchbox.Text == "")
                {
                    cmd.CommandText = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'";
                    printreport = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'";
                }
                else
                {
                    cmd.CommandText = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'AND  (Scented like '%" + searchbox.Text + "%'or Username like '%" + searchbox.Text + "%')";
                    printreport = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'AND  (Scented like '%" + searchbox.Text + "%'or Username like '%" + searchbox.Text + "%')";
                }

                MySqlDataAdapter da1 = new MySqlDataAdapter(cmd);
                da1.Fill(ds);
                sum = 0;
                num = 0;
                MySqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    sum = sum + int.Parse(read["Price"].ToString());
                    num = num + int.Parse(read["Amount"].ToString());
                }
                read.Close();
                conn.Close();
                dataStock.DataSource = ds.Tables[0].DefaultView;
                pricehistory.Text = $"{sum}";
                amounthistory.Text = $"{num}";
                rebill();
            }
            else
            {
                if (searchbox.Text == "")
                {
                    cmd.CommandText = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'";
                    printreport = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'";
                }
                else
                {
                    cmd.CommandText = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'AND  (Scented like '%" + searchbox.Text + "%'or Username like '%" + searchbox.Text + "%')";
                    printreport = $"SELECT * FROM history Where Time like '%" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "%'AND  (Scented like '%" + searchbox.Text + "%'or Username like '%" + searchbox.Text + "%')";
                }

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(ds);
                sum = 0;
                num = 0;
                MySqlDataReader read = cmd.ExecuteReader();
                while (read.Read())
                {
                    sum = sum + int.Parse(read["Price"].ToString());
                    num = num + int.Parse(read["Amount"].ToString());
                }
                read.Close();
                conn.Close();
                dataStock.DataSource = ds.Tables[0].DefaultView;
                pricehistory.Text = $"{sum}";
                amounthistory.Text = $"{num}";
                rebill();
            }
        }

        private void print_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }
        private void rebill()  ///ส่วนของการปริ้นใบเสร็จประวัติการขาย
        {
            MySqlConnection conn = databaseConection();
            conn.Open();
            DataSet ds = new DataSet();
            MySqlCommand bnn = new MySqlCommand(printreport, conn);
            MySqlDataAdapter da = new MySqlDataAdapter(bnn);
            da.SelectCommand.Parameters.AddWithValue("@date1", dateTimePicker1.Value.ToString("yyyy-MM-dd"));
            da.SelectCommand.Parameters.AddWithValue("@date2", dateTimePicker2.Value.ToString("yyyy-MM-dd"));
            da.Fill(ds);

            MySqlDataReader adapter = bnn.ExecuteReader();
            while (adapter.Read())
            {
                Program.name_Bill = adapter.GetString("Scented").ToString();
                Program.size_Bill = adapter.GetString("Size").ToString();
                Program.price_Bill = adapter.GetString("Price").ToString();
                Program.amount_Bill = adapter.GetString("Amount").ToString();

                Bill item = new Bill()
                {
                    name_Bill = Program.name_Bill,
                    size_Bill = Program.size_Bill,
                    price_Bill = Program.price_Bill,
                    amount_Bill = Program.amount_Bill,
                };
                allbill.Add(item);
            }
            conn.Close();
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)///ปริ้นสต๊อก
        {
            e.Graphics.DrawString("DUFTKERZEN", new Font("supermarket", 30, FontStyle.Bold), Brushes.MediumSeaGreen, new Point(75, 100));
            e.Graphics.DrawString("Date : " + System.DateTime.Now.ToString(" dd/MM/yyyy "), new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(80, 230));
            e.Graphics.DrawString("Time : " + System.DateTime.Now.ToString("HH : mm : ss "), new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(80, 260));
            if (stocksearch.Text == "")
            {
                e.Graphics.DrawString("Stock Scented Candles", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 200));
            }
            else
            {
                e.Graphics.DrawString("Scented : " + stocksearch.Text, new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 200));
            }

            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 285));
            e.Graphics.DrawString("Scented                           Size                       Amount                    Price", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 315));
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 345));
            int number = 1;
            int y = 345;

            foreach (var i in allbill)
            {
                y = y + 35;
                e.Graphics.DrawString("   " + i.name_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(70, y));
                e.Graphics.DrawString("   " + i.size_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(280, y));
                e.Graphics.DrawString("   " + i.amount_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(520, y));
                e.Graphics.DrawString("   " + i.price_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(700, y));
                number = number + 1;
            }
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, y + 30));
        }

        private void printstock_Click(object sender, EventArgs e)
        {
            printPreviewDialog2.Document = printDocument2;
            printPreviewDialog2.ShowDialog();
        }

        public string checkstock;
        private void rebills()  ///ส่วนของการปริ้นใบเสร็จสต๊อก
        {
            MySqlConnection conn = databaseConection();
            conn.Open();
            DataSet ds = new DataSet();
            MySqlCommand bnn = new MySqlCommand(checkstock, conn);
            MySqlDataAdapter da = new MySqlDataAdapter(bnn);
            da.Fill(ds);

            MySqlDataReader adapter = bnn.ExecuteReader();
            while (adapter.Read())
            {
                Program.name_Bill = adapter.GetString("Scented").ToString();
                Program.size_Bill = adapter.GetString("Size").ToString();
                Program.price_Bill = adapter.GetString("Price").ToString();
                Program.amount_Bill = adapter.GetString("Amount").ToString();

                Bill item = new Bill()
                {
                    name_Bill = Program.name_Bill,
                    size_Bill = Program.size_Bill,
                    price_Bill = Program.price_Bill,
                    amount_Bill = Program.amount_Bill,
                };
                allbill.Add(item);
            }
            conn.Close();
        }

        private void stocksearch_TextChanged(object sender, EventArgs e)
        {
            allbill.Clear();
            MySqlConnection conn = databaseConection();
            DataSet ds = new DataSet();
            conn.Open();
            MySqlCommand cmd;

            cmd = conn.CreateCommand();

                if (stocksearch.Text == "")
                {
                    cmd.CommandText = $"SELECT * FROM equipment";
                    checkstock = $"SELECT * FROM equipment";
                }
                else
                {
                    cmd.CommandText = $"SELECT * FROM equipment WHERE Scented like \"%{stocksearch.Text}%\"";
                    checkstock = $"SELECT * FROM equipment WHERE Scented like \"%{stocksearch.Text}%\"";
                }
            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);
            dataEquipment.DataSource = ds.Tables[0].DefaultView;
            conn.Close();
            rebills();

        }

        private void refresh_Click(object sender, EventArgs e)
        {
            showEquipment();
            Scented.Clear();
            Amount.Clear();
            Size.Clear();
            Price.Clear();
        }
    }
}
