﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms2
{
    class Bill
    {
        public string name_Bill { get; set; }
        public string price_Bill { get; set; }
        public string size_Bill { get; set; }
        public string amount_Bill { get; set; }
    }
}
