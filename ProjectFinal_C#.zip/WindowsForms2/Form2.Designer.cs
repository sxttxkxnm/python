﻿
namespace WindowsForms2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.adminpassword = new System.Windows.Forms.TextBox();
            this.adminuser = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.print = new System.Windows.Forms.PictureBox();
            this.search = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pricehistory = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.amounthistory = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.searchbox = new System.Windows.Forms.TextBox();
            this.dataStock = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.update = new System.Windows.Forms.Label();
            this.delete = new System.Windows.Forms.Label();
            this.add = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.dataEquipment = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Addpic = new System.Windows.Forms.Button();
            this.Price = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Size = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Amount = new System.Windows.Forms.TextBox();
            this.Scented = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.stocksearch = new System.Windows.Forms.TextBox();
            this.printstock = new System.Windows.Forms.Button();
            this.showpass = new System.Windows.Forms.CheckBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printPreviewDialog2 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.print)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.search)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataEquipment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(-8, -18);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(323, 731);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 107;
            this.pictureBox4.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Snow;
            this.label21.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label21.Location = new System.Drawing.Point(937, 598);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 38);
            this.label21.TabIndex = 121;
            this.label21.Text = "Sign In";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Snow;
            this.label22.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label22.Location = new System.Drawing.Point(909, 174);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(133, 30);
            this.label22.TabIndex = 123;
            this.label22.Text = "Admin Sign In";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 49.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Snow;
            this.label23.Image = ((System.Drawing.Image)(resources.GetObject("label23.Image")));
            this.label23.Location = new System.Drawing.Point(613, 91);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(447, 104);
            this.label23.TabIndex = 122;
            this.label23.Text = "DUFTKERZEN";
            // 
            // adminpassword
            // 
            this.adminpassword.BackColor = System.Drawing.Color.DarkGray;
            this.adminpassword.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminpassword.ForeColor = System.Drawing.Color.Snow;
            this.adminpassword.Location = new System.Drawing.Point(690, 499);
            this.adminpassword.Name = "adminpassword";
            this.adminpassword.PasswordChar = '*';
            this.adminpassword.Size = new System.Drawing.Size(330, 34);
            this.adminpassword.TabIndex = 120;
            this.adminpassword.TextChanged += new System.EventHandler(this.adminpassword_TextChanged);
            // 
            // adminuser
            // 
            this.adminuser.BackColor = System.Drawing.Color.DarkGray;
            this.adminuser.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminuser.ForeColor = System.Drawing.Color.Snow;
            this.adminuser.Location = new System.Drawing.Point(690, 451);
            this.adminuser.Name = "adminuser";
            this.adminuser.Size = new System.Drawing.Size(330, 34);
            this.adminuser.TabIndex = 119;
            this.adminuser.TextChanged += new System.EventHandler(this.adminuser_TextChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Snow;
            this.label27.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label27.Location = new System.Drawing.Point(539, 502);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(140, 30);
            this.label27.TabIndex = 118;
            this.label27.Text = "PASSWORD  :  ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Snow;
            this.label28.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label28.Location = new System.Drawing.Point(542, 454);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(137, 30);
            this.label28.TabIndex = 117;
            this.label28.Text = "USERNAME  :  ";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::WindowsForms2.Properties.Resources.a19e9f;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.update);
            this.panel1.Controls.Add(this.delete);
            this.panel1.Controls.Add(this.add);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.dataEquipment);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.Addpic);
            this.panel1.Controls.Add(this.Price);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.Size);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Amount);
            this.panel1.Controls.Add(this.Scented);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.stocksearch);
            this.panel1.Controls.Add(this.printstock);
            this.panel1.Controls.Add(this.refresh);
            this.panel1.Location = new System.Drawing.Point(-8, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1152, 716);
            this.panel1.TabIndex = 124;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::WindowsForms2.Properties.Resources.a19e9f;
            this.panel2.Controls.Add(this.print);
            this.panel2.Controls.Add(this.search);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.pricehistory);
            this.panel2.Controls.Add(this.dateTimePicker2);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.amounthistory);
            this.panel2.Controls.Add(this.dateTimePicker1);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.searchbox);
            this.panel2.Controls.Add(this.dataStock);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Cursor = System.Windows.Forms.Cursors.PanNW;
            this.panel2.Location = new System.Drawing.Point(324, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(825, 716);
            this.panel2.TabIndex = 126;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // print
            // 
            this.print.BackColor = System.Drawing.SystemColors.ControlDark;
            this.print.BackgroundImage = global::WindowsForms2.Properties.Resources.a19e9f;
            this.print.Image = ((System.Drawing.Image)(resources.GetObject("print.Image")));
            this.print.Location = new System.Drawing.Point(616, 462);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(90, 77);
            this.print.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.print.TabIndex = 160;
            this.print.TabStop = false;
            this.print.Click += new System.EventHandler(this.print_Click);
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.SystemColors.ControlDark;
            this.search.BackgroundImage = global::WindowsForms2.Properties.Resources.a19e9f;
            this.search.Image = ((System.Drawing.Image)(resources.GetObject("search.Image")));
            this.search.Location = new System.Drawing.Point(509, 462);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(86, 77);
            this.search.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.search.TabIndex = 0;
            this.search.TabStop = false;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Snow;
            this.label9.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label9.Location = new System.Drawing.Point(299, 518);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 21);
            this.label9.TabIndex = 159;
            this.label9.Text = "TO";
            // 
            // pricehistory
            // 
            this.pricehistory.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pricehistory.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricehistory.ForeColor = System.Drawing.Color.Snow;
            this.pricehistory.Location = new System.Drawing.Point(569, 225);
            this.pricehistory.Name = "pricehistory";
            this.pricehistory.Size = new System.Drawing.Size(135, 27);
            this.pricehistory.TabIndex = 158;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarFont = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.CalendarMonthBackground = System.Drawing.SystemColors.ControlDark;
            this.dateTimePicker2.CalendarTitleBackColor = System.Drawing.SystemColors.ControlDark;
            this.dateTimePicker2.Font = new System.Drawing.Font("Franklin Gothic Book", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(334, 514);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(148, 30);
            this.dateTimePicker2.TabIndex = 154;
            this.dateTimePicker2.Value = new System.DateTime(2021, 6, 24, 22, 8, 27, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Snow;
            this.label10.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label10.Location = new System.Drawing.Point(130, 225);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 25);
            this.label10.TabIndex = 153;
            this.label10.Text = "AMOUNT";
            // 
            // amounthistory
            // 
            this.amounthistory.BackColor = System.Drawing.SystemColors.ControlDark;
            this.amounthistory.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amounthistory.ForeColor = System.Drawing.Color.Snow;
            this.amounthistory.Location = new System.Drawing.Point(213, 225);
            this.amounthistory.Name = "amounthistory";
            this.amounthistory.Size = new System.Drawing.Size(135, 27);
            this.amounthistory.TabIndex = 152;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CalendarForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.SystemColors.ControlDark;
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.SystemColors.ControlDark;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dateTimePicker1.Font = new System.Drawing.Font("Franklin Gothic Book", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(135, 512);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(152, 30);
            this.dateTimePicker1.TabIndex = 151;
            this.dateTimePicker1.Value = new System.DateTime(2021, 6, 24, 22, 8, 27, 0);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Snow;
            this.label11.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label11.Location = new System.Drawing.Point(456, 225);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 25);
            this.label11.TabIndex = 150;
            this.label11.Text = "TOTAL PRICE";
            // 
            // searchbox
            // 
            this.searchbox.BackColor = System.Drawing.SystemColors.ControlDark;
            this.searchbox.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchbox.ForeColor = System.Drawing.Color.Snow;
            this.searchbox.Location = new System.Drawing.Point(135, 474);
            this.searchbox.Name = "searchbox";
            this.searchbox.Size = new System.Drawing.Size(347, 27);
            this.searchbox.TabIndex = 146;
            // 
            // dataStock
            // 
            this.dataStock.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataStock.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.dataStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataStock.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataStock.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataStock.EnableHeadersVisualStyles = false;
            this.dataStock.GridColor = System.Drawing.Color.DarkKhaki;
            this.dataStock.Location = new System.Drawing.Point(135, 271);
            this.dataStock.Name = "dataStock";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataStock.RowHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.dataStock.RowHeadersVisible = false;
            this.dataStock.RowHeadersWidth = 60;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.Color.White;
            this.dataStock.RowsDefaultCellStyle = dataGridViewCellStyle36;
            this.dataStock.RowTemplate.Height = 24;
            this.dataStock.Size = new System.Drawing.Size(571, 179);
            this.dataStock.TabIndex = 140;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Snow;
            this.label3.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label3.Location = new System.Drawing.Point(593, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 30);
            this.label3.TabIndex = 126;
            this.label3.Text = "ADMIN Sale History";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 49.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Snow;
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(306, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(447, 104);
            this.label4.TabIndex = 125;
            this.label4.Text = "DUFTKERZEN";
            // 
            // update
            // 
            this.update.AutoSize = true;
            this.update.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.ForeColor = System.Drawing.Color.Snow;
            this.update.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.update.Location = new System.Drawing.Point(570, 626);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(83, 30);
            this.update.TabIndex = 144;
            this.update.Text = "UPDATE";
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // delete
            // 
            this.delete.AutoSize = true;
            this.delete.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.ForeColor = System.Drawing.Color.Snow;
            this.delete.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.delete.Location = new System.Drawing.Point(757, 626);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(78, 30);
            this.delete.TabIndex = 143;
            this.delete.Text = "DELETE";
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // add
            // 
            this.add.AutoSize = true;
            this.add.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add.ForeColor = System.Drawing.Color.Snow;
            this.add.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.add.Location = new System.Drawing.Point(407, 626);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(51, 30);
            this.add.TabIndex = 142;
            this.add.Text = "ADD";
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Snow;
            this.label8.Image = ((System.Drawing.Image)(resources.GetObject("label8.Image")));
            this.label8.Location = new System.Drawing.Point(653, 489);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 25);
            this.label8.TabIndex = 141;
            this.label8.Text = "Size :";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(899, 261);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(169, 172);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 140;
            this.pictureBox3.TabStop = false;
            // 
            // dataEquipment
            // 
            this.dataEquipment.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataEquipment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dataEquipment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataEquipment.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataEquipment.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataEquipment.EnableHeadersVisualStyles = false;
            this.dataEquipment.GridColor = System.Drawing.Color.DarkKhaki;
            this.dataEquipment.Location = new System.Drawing.Point(408, 261);
            this.dataEquipment.Name = "dataEquipment";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataEquipment.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dataEquipment.RowHeadersVisible = false;
            this.dataEquipment.RowHeadersWidth = 60;
            dataGridViewCellStyle40.BackColor = System.Drawing.Color.AntiqueWhite;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.Color.White;
            this.dataEquipment.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.dataEquipment.RowTemplate.Height = 24;
            this.dataEquipment.Size = new System.Drawing.Size(427, 193);
            this.dataEquipment.TabIndex = 139;
            this.dataEquipment.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataEquipment_CellClick);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.textBox1.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Snow;
            this.textBox1.Location = new System.Drawing.Point(872, 445);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(225, 27);
            this.textBox1.TabIndex = 138;
            // 
            // Addpic
            // 
            this.Addpic.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Addpic.BackgroundImage")));
            this.Addpic.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addpic.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Addpic.Location = new System.Drawing.Point(872, 488);
            this.Addpic.Name = "Addpic";
            this.Addpic.Size = new System.Drawing.Size(107, 47);
            this.Addpic.TabIndex = 137;
            this.Addpic.Text = "SEARCH";
            this.Addpic.UseVisualStyleBackColor = true;
            this.Addpic.Click += new System.EventHandler(this.Addpic_Click);
            // 
            // Price
            // 
            this.Price.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Price.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price.ForeColor = System.Drawing.Color.Snow;
            this.Price.Location = new System.Drawing.Point(656, 573);
            this.Price.Name = "Price";
            this.Price.Size = new System.Drawing.Size(179, 25);
            this.Price.TabIndex = 135;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Snow;
            this.label12.Image = ((System.Drawing.Image)(resources.GetObject("label12.Image")));
            this.label12.Location = new System.Drawing.Point(76, 552);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(188, 38);
            this.label12.TabIndex = 145;
            this.label12.Text = "STOCK CANDLE";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Snow;
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.Location = new System.Drawing.Point(653, 545);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 25);
            this.label5.TabIndex = 134;
            this.label5.Text = "Price :";
            // 
            // Size
            // 
            this.Size.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Size.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Size.ForeColor = System.Drawing.Color.Snow;
            this.Size.Location = new System.Drawing.Point(658, 517);
            this.Size.Name = "Size";
            this.Size.Size = new System.Drawing.Size(179, 25);
            this.Size.TabIndex = 133;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Snow;
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.Location = new System.Drawing.Point(409, 545);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 25);
            this.label6.TabIndex = 132;
            this.label6.Text = "Amount :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Snow;
            this.label7.Image = ((System.Drawing.Image)(resources.GetObject("label7.Image")));
            this.label7.Location = new System.Drawing.Point(405, 489);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 25);
            this.label7.TabIndex = 131;
            this.label7.Text = "Scented :";
            // 
            // Amount
            // 
            this.Amount.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Amount.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Amount.ForeColor = System.Drawing.Color.Snow;
            this.Amount.Location = new System.Drawing.Point(408, 573);
            this.Amount.Name = "Amount";
            this.Amount.Size = new System.Drawing.Size(179, 25);
            this.Amount.TabIndex = 130;
            // 
            // Scented
            // 
            this.Scented.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Scented.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Scented.ForeColor = System.Drawing.Color.Snow;
            this.Scented.Location = new System.Drawing.Point(410, 515);
            this.Scented.Name = "Scented";
            this.Scented.Size = new System.Drawing.Size(179, 25);
            this.Scented.TabIndex = 129;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Snow;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.Location = new System.Drawing.Point(79, 601);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(173, 38);
            this.label13.TabIndex = 125;
            this.label13.Text = "SALE HISTORY";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Snow;
            this.label2.Image = global::WindowsForms2.Properties.Resources.a19e9f;
            this.label2.Location = new System.Drawing.Point(865, 177);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 30);
            this.label2.TabIndex = 124;
            this.label2.Text = "ADMIN Stock Candles";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 49.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Snow;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(621, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(447, 104);
            this.label1.TabIndex = 123;
            this.label1.Text = "DUFTKERZEN";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(323, 731);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 108;
            this.pictureBox1.TabStop = false;
            // 
            // stocksearch
            // 
            this.stocksearch.BackColor = System.Drawing.SystemColors.ControlDark;
            this.stocksearch.Font = new System.Drawing.Font("Franklin Gothic Book", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocksearch.ForeColor = System.Drawing.Color.Snow;
            this.stocksearch.Location = new System.Drawing.Point(408, 217);
            this.stocksearch.Name = "stocksearch";
            this.stocksearch.Size = new System.Drawing.Size(296, 27);
            this.stocksearch.TabIndex = 147;
            this.stocksearch.TextChanged += new System.EventHandler(this.stocksearch_TextChanged);
            // 
            // printstock
            // 
            this.printstock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("printstock.BackgroundImage")));
            this.printstock.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printstock.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.printstock.Location = new System.Drawing.Point(990, 488);
            this.printstock.Name = "printstock";
            this.printstock.Size = new System.Drawing.Size(107, 47);
            this.printstock.TabIndex = 146;
            this.printstock.Text = "PRINT";
            this.printstock.UseVisualStyleBackColor = true;
            this.printstock.Click += new System.EventHandler(this.printstock_Click);
            // 
            // showpass
            // 
            this.showpass.AutoSize = true;
            this.showpass.BackgroundImage = global::WindowsForms2.Properties.Resources.a19e9f;
            this.showpass.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showpass.ForeColor = System.Drawing.Color.Snow;
            this.showpass.Location = new System.Drawing.Point(883, 552);
            this.showpass.Name = "showpass";
            this.showpass.Size = new System.Drawing.Size(137, 22);
            this.showpass.TabIndex = 125;
            this.showpass.Text = "SHOW PASSWORD ?";
            this.showpass.UseVisualStyleBackColor = true;
            this.showpass.CheckedChanged += new System.EventHandler(this.showpass_CheckedChanged);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // printPreviewDialog2
            // 
            this.printPreviewDialog2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog2.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog2.Enabled = true;
            this.printPreviewDialog2.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog2.Icon")));
            this.printPreviewDialog2.Name = "printPreviewDialog1";
            this.printPreviewDialog2.Visible = false;
            // 
            // printDocument2
            // 
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument2_PrintPage);
            // 
            // refresh
            // 
            this.refresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("refresh.BackgroundImage")));
            this.refresh.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.refresh.Location = new System.Drawing.Point(730, 211);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(105, 39);
            this.refresh.TabIndex = 150;
            this.refresh.Text = "REFRESH";
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsForms2.Properties.Resources.a19e9f;
            this.ClientSize = new System.Drawing.Size(1138, 702);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.adminpassword);
            this.Controls.Add(this.adminuser);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.showpass);
            this.Cursor = System.Windows.Forms.Cursors.PanNW;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.print)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.search)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataEquipment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox adminpassword;
        private System.Windows.Forms.TextBox adminuser;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataStock;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label update;
        private System.Windows.Forms.Label delete;
        private System.Windows.Forms.Label add;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.DataGridView dataEquipment;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Addpic;
        private System.Windows.Forms.TextBox Price;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Size;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Amount;
        private System.Windows.Forms.TextBox Scented;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox showpass;
        private System.Windows.Forms.TextBox searchbox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox amounthistory;
        private System.Windows.Forms.TextBox pricehistory;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox print;
        private System.Windows.Forms.PictureBox search;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Button printstock;
        private System.Windows.Forms.TextBox stocksearch;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog2;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private System.Windows.Forms.Button refresh;
    }
}