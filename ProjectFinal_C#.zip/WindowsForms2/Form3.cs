﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;

namespace WindowsForms2
{
    public partial class Form3 : Form
    {
        List<Bill> allbill = new List<Bill>();
        private MySqlConnection databaseConection()
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connectionString);
            return conn;
        }

        private void showEquipment()
        {
            MySqlConnection conn = databaseConection();
            DataSet ds = new DataSet();
            conn.Open();
            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT *FROM equipment";

            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);

            conn.Close();

            dataEquipment.DataSource = ds.Tables[0].DefaultView;
        }

        private void showCart()
        {
            MySqlConnection conn = databaseConection();
            DataSet ds = new DataSet();
            conn.Open();
            MySqlCommand cmd;

            cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT *FROM cart";

            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);

            conn.Close();

            dataCart.DataSource = ds.Tables[0].DefaultView;
        }
        public Form3()
        {
            InitializeComponent();
        }
        /// <summary>
        /// กำหนคตัวแปรเพื่อเก็บค่าต่างๆ
        /// </summary>
        public string user;
        string r;
        int sums;


        private void selectamountadmin()///เลือกจำนวนจากstock มาคำนวณ
        {
            string scente = scented.Text;
            string connection = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connection);
            conn.Open();
            string sql = $"SELECT Amount FROM equipment WHERE Scented =\"{scente}\" ";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            MySqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                r = dr.GetValue(0).ToString();
            }
        }

        private void clearpage()
        {
            scentes.ResetText();
            sizes.ResetText();
            amounts.ResetText();
            total.Text = "";
            recieve.Text = "";
            change.Text = "";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            showEquipment();
            showCart();
            panel1.Hide();
        }

        private void label21_Click(object sender, EventArgs e)
        {
            panel1.Hide();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            panel1.Show();
        }

        public string stockamount;///สร้างไว้เก็บจำนวน
        public string pricestock;///สร้างไว้เก็บราคาคิดเงิน

        private void dataEquipment_CellClick(object sender, DataGridViewCellEventArgs e)///ในสต๊อก
        {
            dataEquipment.CurrentRow.Selected = true;
            scented.Text = dataEquipment.Rows[e.RowIndex].Cells["Scented"].FormattedValue.ToString();
            size.Text = dataEquipment.Rows[e.RowIndex].Cells["Size"].FormattedValue.ToString();
            stockamount = dataEquipment.Rows[e.RowIndex].Cells["Amount"].FormattedValue.ToString();
            pricestock = dataEquipment.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();
            price.Text = dataEquipment.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connectionString);
            conn.Open();
            MySqlCommand cmd = new MySqlCommand($"SELECT image FROM equipment WHERE Scented =\"{ scented.Text }\"", conn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["Image"]);
                pictureBox3.Image = new Bitmap(ms);
            }
        }

        public string pricse;///สร้างไว้เก็บราคาในตะกร้า
        public string amountstock;///สร้าไว้เก็บจำนวนในตะกร้า

        private void dataCart_CellClick(object sender, DataGridViewCellEventArgs e)///ในตะกร้า
        {
            dataCart.CurrentRow.Selected = true;
            scentes.Text = dataCart.Rows[e.RowIndex].Cells["Scented"].FormattedValue.ToString();
            sizes.Text = dataCart.Rows[e.RowIndex].Cells["Size"].FormattedValue.ToString();
            amounts.Text = dataCart.Rows[e.RowIndex].Cells["Amount"].FormattedValue.ToString();
            amountstock = dataCart.Rows[e.RowIndex].Cells["Amount"].FormattedValue.ToString();
            pricse = dataCart.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();

        }

        string b;
        string w;
        int v = 0;

        private void sum()///คำนวณราคาหลังกดสั่งสินค้า
        {
            w = (pricestock);
            int numbert = int.Parse(w);
            b = $"{amount.Text}";
            int numbers = int.Parse(b);
            v = numbert * numbers;
            sumprice = sumprice + numbert * numbers;
            price.Text = ($"{v}");
            total.Text = ($"{sumprice}");
        }

        private void summ()///คำนวณราคาหลังลบสินค้า
        {
            MySqlConnection connn = databaseConection();
            MySqlCommand cmdd;
            cmdd = connn.CreateCommand();
            connn.Open();
            sumprice = 0;
            cmdd.CommandText = $"SELECT * FROM cart";
            MySqlDataReader read = cmdd.ExecuteReader();
            while (read.Read())
            {
                sumprice = sumprice + int.Parse(read["Price"].ToString());
            }
            read.Close();
            connn.Close();
            total.Text = $"{sumprice}";
        }

        private void ADD_Click(object sender, EventArgs e)
        {
            sum();
            MySqlConnection connn = databaseConection();
            String sqll = "INSERT INTO cart(Scented, Size, Amount, Price) VALUES('" + scented.Text + "','" + size.Text + "','" + amount.Text + "','" + price.Text + "')";
            MySqlCommand cmdd = new MySqlCommand(sqll, connn);

            connn.Open();

            int rows = cmdd.ExecuteNonQuery();

            connn.Close();
            if (rows > 0)
            {
                showCart();
            }

            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection connl = new MySqlConnection(connectionString);
            connl.Open();
            selectamountadmin();
            int All_A = int.Parse(r);
            int All_W = int.Parse(amount.Text);
            int All_Aad = All_A - All_W;
            string All_amountadmin = All_Aad.ToString();
            string connections = "datasource=127.0.0.1;port=3306;username=root;password=;database=project;charset=utf8;";
            MySqlConnection conn = new MySqlConnection(connections);
            String sql = "UPDATE equipment SET Amount ='" + All_amountadmin + "'WHERE Scented ='" + scented.Text + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            int rosws = cmd.ExecuteNonQuery();
            if (rosws > 0)
            {
                MessageBox.Show("Add To Cart");
                showEquipment();
                scented.ResetText();
                size.ResetText();
                amount.ResetText();
                price.ResetText();
            }
        }

        string p;
        string t;

        private void checkout_Click(object sender, EventArgs e)
        {
            rebill();
            p = ($"{recieve.Text}");
            int numberf = int.Parse(p);
            t = ($"{total.Text}");
            int numbers = int.Parse(t);
            sums = numberf - numbers;

            if (numberf < numbers)
            {
                MessageBox.Show("Check out not successfull");
                recieve.ResetText();
            }
            else
            {
                change.Text = ($"{sums}");
                total.Text = ($"{sumprice}");
                MessageBox.Show("Thank You");
                insert_to_cart();
                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
                clearpage();
            }
        }

 
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("DUFTKERZEN", new Font("supermarket", 36, FontStyle.Bold), Brushes.MediumSeaGreen, new Point(70, 100));
            e.Graphics.DrawString("Name : " + user, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 200));
            e.Graphics.DrawString("Date : " + System.DateTime.Now.ToString(" dd/MM/yyyy "), new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(80,230));
            e.Graphics.DrawString("Time : " + System.DateTime.Now.ToString("HH : mm : ss "), new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(80, 260));
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 285));
            e.Graphics.DrawString("Scented                         Size                        Amount                     Price", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 315));
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, 345));
            int number = 1;
            int y = 345;

            foreach (var i in allbill)
            {
                y = y + 35;
                e.Graphics.DrawString("   " + i.name_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(70, y));
                e.Graphics.DrawString("   " + i.size_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(280, y));
                e.Graphics.DrawString("   " + i.amount_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(520, y));
                e.Graphics.DrawString("   " + i.price_Bill, new Font("supermarket", 14, FontStyle.Regular), Brushes.MediumSeaGreen, new PointF(700, y));
                number = number + 1;
            }
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(80, y + 30));
            e.Graphics.DrawString("Total           " + total.Text + " Baht", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(570, ((y + 30) + 45) + 45));
            e.Graphics.DrawString("Recieve      " + recieve.Text + " Baht", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(570, (((y + 30) + 45) + 45) + 45));
            e.Graphics.DrawString("Change       " + change.Text + " Baht", new Font("supermarket", 16, FontStyle.Regular), Brushes.MediumSeaGreen, new Point(570, ((((y + 30) + 45) + 45) + 45) + 45));
        }

        private int oldamounts;
        public int sumprice;

        private void update_Click(object sender, EventArgs e)
        {
            int selected = dataCart.CurrentCell.RowIndex;
            string edit = Convert.ToString(dataCart.Rows[selected].Cells["Scented"].Value);
            int oldamount = int.Parse(amountstock);
            int newamount = int.Parse(amounts.Text);
            int oldprice = int.Parse(pricse);
            int pricenew = oldprice / oldamount;
            int newprice = pricenew * newamount;
            
            MySqlConnection conn = databaseConection();
            conn.Open();
            string selectsql = "SELECT * FROM equipment WHERE Scented ='" + scentes.Text + "'";
            MySqlCommand cmdl = new MySqlCommand(selectsql, conn);
            oldamounts = 0;
            using (MySqlDataReader read = cmdl.ExecuteReader())
            {
                read.Read();
                string stockam = (read["Amount"].ToString());
                int.TryParse(stockam, out oldamounts);
                read.Close();
            }
            string sql = "UPDATE cart set Price ='" + newprice + "', Amount = '" + newamount + "'Where Scented = '" + edit + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            if(oldamount > newamount)
            {
                int pass = oldamount - newamount;
                int news = oldamounts + pass;
                string sql2 = "UPDATE equipment set Amount = '" + news + "'Where Scented = '" + scentes.Text + "'";
                MySqlCommand cmd2 = new MySqlCommand(sql2, conn);

                int rows = cmd2.ExecuteNonQuery();
                conn.Close();
                if(rows > 0)
                {
                    MessageBox.Show("Update Cart");
                    showEquipment();
                    showCart();
                    MySqlConnection connn = databaseConection();
                    MySqlCommand cmdd;
                    cmdd = connn.CreateCommand();
                    connn.Open();
                    sumprice = 0;
                    cmdd.CommandText = $"SELECT * FROM cart";
                    MySqlDataReader read = cmdd.ExecuteReader();
                    while(read.Read())
                    {
                        sumprice = sumprice + int.Parse(read["Price"].ToString());
                    }
                    read.Close();
                    connn.Close();
                    total.Text = $"{sumprice}";
                }
            }
            if (oldamount < newamount)
            {
                int del = newamount - oldamount;
                int news = oldamounts - del;
                string sql3 = "UPDATE equipment set Amount = '" + news + "'Where Scented = '" + scentes.Text + "'";
                MySqlCommand cmd3 = new MySqlCommand(sql3, conn);

                int rows2 = cmd3.ExecuteNonQuery();
                conn.Close();
                if (rows2 > 0)
                {
                    MessageBox.Show("Update Cart");
                    showEquipment();
                    showCart();
                    MySqlConnection connn = databaseConection();
                    MySqlCommand cmdd;
                    cmdd = connn.CreateCommand();
                    connn.Open();
                    sumprice = 0;
                    cmdd.CommandText = $"SELECT * FROM cart";
                    MySqlDataReader read = cmdd.ExecuteReader();
                    while (read.Read())
                    {
                        sumprice = sumprice + int.Parse(read["Price"].ToString());
                    }
                    read.Close();
                    connn.Close();
                    total.Text = $"{sumprice}";

                }
            }    
        }

        string name_item;
        string size_item;
        string amount_item;
        string price_item;

        private void insert_to_cart()
        {
            MySqlConnection conn = databaseConection();
            MySqlCommand bnn = new MySqlCommand("SELECT * FROM cart ", conn);
            conn.Open();
            MySqlDataReader adapter = bnn.ExecuteReader();
            while (adapter.Read())
            {
                name_item = adapter.GetString("Scented").ToString();
                size_item = adapter.GetString("Size").ToString();
                amount_item = adapter.GetString("Amount").ToString();
                price_item = adapter.GetString("Price").ToString();
                MySqlConnection con = databaseConection();
                string sql = "INSERT INTO history (Username,Scented,Size,Amount,Price) VALUES('" + user + "','" + name_item + "','" + size_item + "','" + amount_item + "','" + price_item + "')";
                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }

            conn.Close();
            MySqlConnection conn3 = databaseConection();
            conn3.Open();
            MySqlCommand cmd3 = conn3.CreateCommand();
            cmd3.CommandText = "TRUNCATE TABLE cart"; /// TRUNCATE คือ delete เเเต่เร็วกว่า
            cmd3.ExecuteNonQuery();
            conn3.Close();
        }

        public string printreport;
        private void rebill()  ///ส่วนของการปริ้นใบเสร็จ
        {
            MySqlConnection conn = databaseConection();
            conn.Open();
            MySqlCommand bnn = new MySqlCommand("SELECT * FROM cart", conn);

            MySqlDataReader adapter = bnn.ExecuteReader();
            while (adapter.Read())
            {
                Program.name_Bill = adapter.GetString("Scented").ToString();
                Program.size_Bill = adapter.GetString("Size").ToString();
                Program.amount_Bill = adapter.GetString("Amount").ToString();
                Program.price_Bill = adapter.GetString("Price").ToString();

                Bill item = new Bill()
                {
                    name_Bill = Program.name_Bill,
                    size_Bill = Program.size_Bill,
                    amount_Bill = Program.amount_Bill,
                    price_Bill = Program.price_Bill,
                };
                allbill.Add(item);
            }
            conn.Close();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            int selectedRow = dataCart.CurrentCell.RowIndex;
            string deleteId = Convert.ToString(dataCart.Rows[selectedRow].Cells["Scented"].Value);
   
            MySqlConnection conn = databaseConection();

            String sql = "DELETE FROM cart WHERE Scented ='" + deleteId + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();

            cmd.ExecuteNonQuery();
            
            conn.Close();

            MySqlConnection con = databaseConection();
            con.Open();

            string selectSql = "SELECT Amount FROM equipment where Scented ='" + scentes.Text + "'";
            MySqlCommand cmd3 = new MySqlCommand(selectSql, con);
            int oldamounts;
            using (MySqlDataReader read = cmd3.ExecuteReader())
            {
                read.Read();
                string old_number = read["Amount"].ToString();
                int.TryParse(old_number, out oldamounts);
                read.Close();
            }

            int old_price_number = int.Parse(amountstock);
            int newstock_number = oldamounts + old_price_number;

            string sql4 = "UPDATE equipment set Amount ='" + newstock_number + "'Where Scented = '" + scentes.Text + "'";
            MySqlCommand cmd4 = new MySqlCommand(sql4, con);

            int rows = cmd4.ExecuteNonQuery();

            con.Close();

            if (rows > 0)
            {
                MessageBox.Show("Delete Successfull");
                showCart();
                showEquipment();
                summ();
            }

        }
    }
}
